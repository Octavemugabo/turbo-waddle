package model;

public enum MembershipStatus {
	
	APPROVED, REJECTED, PENDING
	
}
