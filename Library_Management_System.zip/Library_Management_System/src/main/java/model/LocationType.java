package model;

public enum LocationType {
	PROVINCE, DISTRICT, SECTOR, CELL, VILLAGE
}
