package model;

public enum BookStatus {
	BORROWED, RESERVED, AVAILABLE
}
