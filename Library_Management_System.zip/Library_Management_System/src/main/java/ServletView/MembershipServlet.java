package ServletView;

import dao.MembershipDAO;
import model.Membership;
import model.MembershipTypeBook;
import model.PersonUser;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/membership")
public class MembershipServlet extends HttpServlet {
 
	private static final long serialVersionUID = 1L;
	private MembershipDAO membershipDAO;

    @Override
    public void init() throws ServletException {
        membershipDAO = new MembershipDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if (action == null) {
            response.sendRedirect("membership-list.jsp");
        } else {
            switch (action) {
                case "new":
                    showNewForm(request, response);
                    break;
                case "edit":
                    showEditForm(request, response);
                    break;
                case "delete":
                    deleteMembership(request, response);
                    break;
                default:
                    response.sendRedirect("membership-list.jsp");
                    break;
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if (action == null) {
            response.sendRedirect("membership-list.jsp");
        } else {
            switch (action) {
                case "insert":
                    insertMembership(request, response);
                    break;
                case "update":
                    updateMembership(request, response);
                    break;
                default:
                    response.sendRedirect("membership-list.jsp");
                    break;
            }
        }
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("membership-form.jsp").forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Long membershipId = Long.parseLong(request.getParameter("id"));
        Membership existingMembership = membershipDAO.findById(membershipId);
        request.setAttribute("membership", existingMembership);
        request.getRequestDispatcher("membership-form.jsp").forward(request, response);
    }

    private void insertMembership(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String membershipCode = request.getParameter("membershipCode");
        String registrationDate = request.getParameter("registrationDate");
        String membershipStatus = request.getParameter("membershipStatus");
        String membershipType = request.getParameter("membershipType");
        String expirationDate = request.getParameter("expirationDate");

        PersonUser personUser = new PersonUser(); 
        personUser.setPersonId(Long.parseLong(request.getParameter("personUserId")));

        MembershipTypeBook membershipTypeBook = new MembershipTypeBook(); 
        membershipTypeBook.setMembership_book_Id(Long.parseLong(request.getParameter("membershipTypeId")));

        Membership newMembership = new Membership();
        newMembership.setMembershipCode(membershipCode);
        newMembership.setRegistration_Date(registrationDate);
        newMembership.setMembershipStatus(membershipStatus);
        newMembership.setMembership_Type(membershipType);
        newMembership.setExpiration_Date(expirationDate);
        newMembership.setPersonUser(personUser);
        newMembership.setMembershipType(membershipTypeBook);

        membershipDAO.save(newMembership);
        response.sendRedirect("membership-list.jsp");
    }

    private void updateMembership(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Long membershipId = Long.parseLong(request.getParameter("membershipId"));
        String membershipCode = request.getParameter("membershipCode");
        String registrationDate = request.getParameter("registrationDate");
        String membershipStatus = request.getParameter("membershipStatus");
        String membershipType = request.getParameter("membershipType");
        String expirationDate = request.getParameter("expirationDate");

        Membership existingMembership = membershipDAO.findById(membershipId);
        if (existingMembership != null) {
            existingMembership.setMembershipCode(membershipCode);
            existingMembership.setRegistration_Date(registrationDate);
            existingMembership.setMembershipStatus(membershipStatus);
            existingMembership.setMembership_Type(membershipType);
            existingMembership.setExpiration_Date(expirationDate);

            PersonUser personUser = new PersonUser();
            personUser.setPersonId(Long.parseLong(request.getParameter("personUserId")));
            existingMembership.setPersonUser(personUser);

            MembershipTypeBook membershipTypeBook = new MembershipTypeBook();
            membershipTypeBook.setMembership_book_Id(membershipId);
            existingMembership.setMembershipType(membershipTypeBook);

            membershipDAO.update(existingMembership);
        }
        response.sendRedirect("membership-list.jsp");
    }

    private void deleteMembership(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Long membershipId = Long.parseLong(request.getParameter("id"));
        membershipDAO.delete(membershipId);
        response.sendRedirect("membership-list.jsp");
    }
}
