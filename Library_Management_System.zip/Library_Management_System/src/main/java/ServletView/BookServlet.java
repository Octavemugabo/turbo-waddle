package ServletView;
import dao.BookDAO;
import model.Book;
import model.BookStatus;
import model.Shelf;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/BookServlet")
public class BookServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private BookDAO bookDAO;

    public void init() {
        bookDAO = new BookDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if (action != null) {
            switch (action) {
                case "create":
                    createBook(request, response);
                    break;
                case "update":
                    updateBook(request, response);
                    break;
                case "delete":
                    deleteBook(request, response);
                    break;
                case "find":
                    findBook(request, response);
                    break;
                default:
                    response.sendRedirect("error.jsp");
                    break;
            }
        }
    }

    private void createBook(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            String title = request.getParameter("title");
            String edition = request.getParameter("edition");
            String isbnCode = request.getParameter("isbnCode");
            String publicationYear = request.getParameter("publicationYear");
            String publisherName = request.getParameter("publisherName");
            BookStatus bookStatus = BookStatus.valueOf(request.getParameter("bookStatus").toUpperCase());
            Long shelfId = Long.parseLong(request.getParameter("shelfId"));

            Shelf shelf = new Shelf();
            shelf.setShelfId(shelfId);

            Book newBook = new Book();
            newBook.setTitle(title);
            newBook.setEdition(edition);
            newBook.setISBNcode(isbnCode);
            newBook.setPublicationYear(publicationYear);
            newBook.setPublisherName(publisherName);
            newBook.setBookStatus(bookStatus);
            newBook.setShelf(shelf);

            bookDAO.save(newBook);
            response.sendRedirect("bookList.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }

    private void updateBook(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            Long bookId = Long.parseLong(request.getParameter("bookId"));
            String title = request.getParameter("title");
            String edition = request.getParameter("edition");
            String isbnCode = request.getParameter("isbnCode");
            String publicationYear = request.getParameter("publicationYear");
            String publisherName = request.getParameter("publisherName");
            BookStatus bookStatus = BookStatus.valueOf(request.getParameter("bookStatus").toUpperCase());
            Long shelfId = Long.parseLong(request.getParameter("shelfId"));

            Shelf shelf = new Shelf();
            shelf.setShelfId(shelfId);

            Book bookToUpdate = bookDAO.findById(bookId);
            if (bookToUpdate != null) {
                bookToUpdate.setTitle(title);
                bookToUpdate.setEdition(edition);
                bookToUpdate.setISBNcode(isbnCode);
                bookToUpdate.setPublicationYear(publicationYear);
                bookToUpdate.setPublisherName(publisherName);
                bookToUpdate.setBookStatus(bookStatus);
                bookToUpdate.setShelf(shelf);

                bookDAO.update(bookToUpdate);
                response.sendRedirect("bookList.jsp");
            } else {
                response.sendRedirect("error.jsp");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }

    private void deleteBook(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            Long bookId = Long.parseLong(request.getParameter("bookId"));
            bookDAO.delete(bookId);
            response.sendRedirect("bookList.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }

    private void findBook(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            Long bookId = Long.parseLong(request.getParameter("bookId"));
            Book book = bookDAO.findById(bookId);
            if (book != null) {
                request.setAttribute("book", book);
                request.getRequestDispatcher("bookDetail.jsp").forward(request, response);
            } else {
                response.sendRedirect("error.jsp");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}
