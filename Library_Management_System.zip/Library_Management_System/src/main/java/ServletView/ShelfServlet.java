package ServletView;

import com.fasterxml.jackson.databind.ObjectMapper;
import dao.ShelfDAO;
import model.Shelf;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/shelves")
public class ShelfServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ShelfDAO shelfDAO = new ShelfDAO();
    private ObjectMapper objectMapper = new ObjectMapper();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("list".equals(action)) {
            listShelves(response);
        } else if ("get".equals(action)) {
            Long shelfId = Long.valueOf(request.getParameter("id"));
            getShelfById(shelfId, response);
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Shelf shelf = objectMapper.readValue(request.getInputStream(), Shelf.class);
        shelfDAO.save(shelf);
        response.setStatus(HttpServletResponse.SC_CREATED);
        response.getWriter().write("Shelf created successfully");
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Shelf shelf = objectMapper.readValue(request.getInputStream(), Shelf.class);
        shelfDAO.update(shelf);
        response.getWriter().write("Shelf updated successfully");
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Long shelfId = Long.valueOf(request.getParameter("id"));
        shelfDAO.delete(shelfId);
        response.getWriter().write("Shelf deleted successfully");
    }

    private void listShelves(HttpServletResponse response) throws IOException {
        List<Shelf> shelves = shelfDAO.findAll();
        response.setContentType("application/json");
        response.getWriter().write(objectMapper.writeValueAsString(shelves));
    }

    private void getShelfById(Long shelfId, HttpServletResponse response) throws IOException {
        Shelf shelf = shelfDAO.findById(shelfId);
        response.setContentType("application/json");
        if (shelf != null) {
            response.getWriter().write(objectMapper.writeValueAsString(shelf));
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Shelf not found");
        }
    }
}
