package dao;

import hibernate.Hibernatecfg;

import model.PersonUser;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.List;

public class PersonUserDAO {

    // Helper method to hash password using SHA-256
    public String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(password.getBytes());
            return Base64.getEncoder().encodeToString(hashedBytes);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not found", e);
        }
    }

    public void save(PersonUser personUser) {
        Transaction transaction = null;
        try (Session session = Hibernatecfg.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            personUser.setPassword(hashPassword(personUser.getPassword()));  // Hash password before saving
            session.persist(personUser);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null && transaction.isActive()) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }


    // Update an existing PersonUser with hashed password
    public void update(PersonUser personUser) {
        Transaction transaction = null;
        try (Session session = Hibernatecfg.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            if (personUser.getPassword() != null && !personUser.getPassword().isEmpty()) {
                personUser.setPassword(hashPassword(personUser.getPassword()));  // Hash new password if provided
            }
            session.update(personUser);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    // Find a PersonUser by ID
    @SuppressWarnings("deprecation")
	public PersonUser findById(Long id) {
        try (Session session = Hibernatecfg.getSessionFactory().openSession()) {
            return session.get(PersonUser.class, id);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Find a PersonUser by username
    public PersonUser findByUsername(String username) {
        try (Session session = Hibernatecfg.getSessionFactory().openSession()) {
            return session.createQuery("FROM PersonUser WHERE username = :username", PersonUser.class)
                          .setParameter("username", username)
                          .uniqueResult();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Find all PersonUsers
    @SuppressWarnings("unchecked")
    public List<PersonUser> findAll() {
        try (Session session = Hibernatecfg.getSessionFactory().openSession()) {
        	return session.createQuery("SELECT p FROM PersonUser p", PersonUser.class).list();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Delete a PersonUser by ID
    public void delete(Long id) {
        Transaction transaction = null;
        try (Session session = Hibernatecfg.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            PersonUser personUser = session.get(PersonUser.class, id);
            if (personUser != null) {
                session.delete(personUser);
                transaction.commit();
            }
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }
 // Find a PersonUser by userId
    @SuppressWarnings("deprecation")
    public PersonUser findByUserId(String userId) {
        try (Session session = Hibernatecfg.getSessionFactory().openSession()) {
            String hql = "FROM PersonUser WHERE userId = :userId";
            return session.createQuery(hql, PersonUser.class)
                          .setParameter("userId", userId)
                          .uniqueResult();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

}
