package dao;

import model.Room;
import org.hibernate.Session;
import org.hibernate.Transaction;
import hibernate.Hibernatecfg;

import java.util.List;

public class RoomDAO {

    // Save a new room
    public void save(Room room) {
        Transaction transaction = null;
        try (Session session = Hibernatecfg.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.persist(room);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    // Update an existing room
    public void update(Room room) {
        Transaction transaction = null;
        try (Session session = Hibernatecfg.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.update(room);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    // Delete a room by ID
    public void delete(Long roomId) {
        Transaction transaction = null;
        try (Session session = Hibernatecfg.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            Room room = session.get(Room.class, roomId);
            if (room != null) {
                session.delete(room);
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    // Find a room by ID
    public Room findById(Long roomId) {
        Room room = null;
        try (Session session = Hibernatecfg.getSessionFactory().openSession()) {
            room = session.get(Room.class, roomId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return room;
    }

    // Find all rooms
    @SuppressWarnings("unchecked")
    public List<Room> findAll() {
        List<Room> rooms = null;
        try (Session session = Hibernatecfg.getSessionFactory().openSession()) {
            rooms = session.createQuery("FROM Room").list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rooms;
    }
}
